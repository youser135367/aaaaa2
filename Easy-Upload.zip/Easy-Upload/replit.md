# Easy Upload

Easy Upload lets users connect GitHub, choose a repository, and commit files or whole folders while preserving their original paths.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secrets: `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET` — GitHub OAuth App credentials

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/github-file-uploader/src/App.tsx` — single-page upload workflow and responsive UI
- `artifacts/github-file-uploader/src/index.css` — Easy Upload visual tokens and motion
- `artifacts/api-server/src/routes/github.ts` — GitHub OAuth, repository creation/listing, upload commits, and branch-emptying endpoint
- `artifacts/api-server/src/lib/github.ts` — GitHub REST API helpers
- `lib/api-spec/openapi.yaml` — source-of-truth API contract
- `attached_assets/generated_images/easy-upload-logo.png` — Easy Upload logo image asset

## Architecture decisions

- GitHub access uses OAuth with an HttpOnly signed cookie so each user can connect their own account without exposing a token to frontend JavaScript.
- Folder selection uses `File.webkitRelativePath`; the server sends all blobs through GitHub's Git Data API and updates one commit, preserving relative paths.
- New repositories are created with GitHub's `auto_init` option so they start with a README and are immediately ready for uploads.
- Empty existing repositories are initialized through GitHub's contents endpoint before the selected branch is created or updated.
- The `/empty-repository` page clears only the selected branch in one non-force commit and requires server-validated acknowledgement plus the `EMPTY` confirmation phrase.
- The app deliberately keeps selected file bytes in browser memory until the user presses the commit button.

## Product

Easy Upload provides a browser-first flow for connecting GitHub, selecting or creating a destination repository and branch, staging files or folders, previewing their preserved paths, sending a commit with a clear result summary, and safely emptying a selected branch when needed.

## User preferences

- Product name: Easy Upload.

## Gotchas

- The GitHub OAuth App callback must match the current app origin at `/api/github/auth/callback`. The server prefers a same-origin callback from the current browser, while `GITHUB_REDIRECT_URI` remains available for deployments that intentionally use a fixed URL.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
