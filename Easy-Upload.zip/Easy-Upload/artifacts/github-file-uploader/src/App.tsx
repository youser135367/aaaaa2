import { useEffect, useState, type InputHTMLAttributes, type ReactNode } from 'react';
import easyUploadLogo from '@assets/generated_images/easy-upload-logo.png';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  AlertCircle,
  ArrowLeft,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronDown,
  CloudUpload,
  Code2,
  Copy,
  ExternalLink,
  FileCode2,
  FileText,
  FolderOpen,
  Github,
  Info,
  Link2,
  Loader2,
  LockKeyhole,
  LogOut,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UploadCloud,
  X,
  XCircle,
} from 'lucide-react';
import {
  getGetGithubAuthStatusQueryKey,
  getHealthCheckQueryKey,
  getListGithubRepositoriesQueryKey,
  useCreateGithubRepository,
  useEmptyGithubRepository,
  useGetGithubAuthStatus,
  useHealthCheck,
  useListGithubRepositories,
  useLogoutGithub,
  useUploadToGithub,
} from '@workspace/api-client-react';
import type {
  GithubCreateRepositoryInput,
  GithubEmptyRepositoryResult,
  GithubRepository,
  GithubUploadResult,
} from '@workspace/api-client-react';
import {
  Link,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type BrowserFile = File & { webkitRelativePath?: string };
type SelectedFile = {
  file: File;
  path: string;
  size: number;
};

const folderInputProps = {
  webkitdirectory: '',
  directory: '',
} as unknown as InputHTMLAttributes<HTMLInputElement>;

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function readAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? '');
      resolve(result.includes(',') ? result.slice(result.indexOf(',') + 1) : result);
    };
    reader.onerror = () => reject(reader.error ?? new Error('Unable to read file'));
    reader.readAsDataURL(file);
  });
}

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error && error.message ? error.message : fallback;
}

function GithubMark({ size = 18 }: { size?: number }) {
  return <Github aria-hidden="true" size={size} strokeWidth={1.8} />;
}

function StatusDot({ tone = 'good' }: { tone?: 'good' | 'muted' | 'bad' }) {
  return (
    <span
      aria-hidden="true"
      className={`inline-block h-2 w-2 rounded-full ${
        tone === 'good'
          ? 'bg-[#b9d83d]'
          : tone === 'bad'
            ? 'bg-[#df7666]'
            : 'bg-[#a0a9a0]'
      }`}
    />
  );
}

function StepRail({
  connected,
  hasRepository,
  hasFiles,
  hasResult,
}: {
  connected: boolean;
  hasRepository: boolean;
  hasFiles: boolean;
  hasResult: boolean;
}) {
  const steps = [
    { label: 'Connect GitHub', detail: connected ? 'Account ready' : 'Required', done: connected },
    { label: 'Choose destination', detail: hasRepository ? 'Repository selected' : 'Repository + branch', done: hasRepository },
    { label: 'Add files', detail: hasFiles ? 'Files staged' : 'Single file or folder', done: hasFiles },
    { label: 'Review & commit', detail: hasResult ? 'Commit sent' : 'Preview before sending', done: hasResult },
  ];

  return (
    <aside className="relative hidden min-h-[calc(100dvh-72px)] w-[256px] shrink-0 overflow-hidden bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))] lg:block">
      <div className="absolute -right-20 top-16 h-48 w-48 rounded-full bg-[hsl(var(--primary)/.08)] blur-3xl" />
      <div className="relative flex h-full flex-col justify-between px-7 py-8">
        <div>
          <div className="mb-12 flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]">
              <CloudUpload size={20} strokeWidth={2.2} />
            </div>
            <div>
              <div className="font-display text-[15px] font-semibold tracking-[-.02em]">easy upload</div>
              <div className="font-mono text-[9px] uppercase tracking-[.16em] text-[hsl(var(--card)/.45)]">github transport</div>
            </div>
          </div>
          <div className="mb-5 font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--card)/.38)]">Your flow</div>
          <ol className="space-y-1">
            {steps.map((step, index) => (
              <li key={step.label} className="relative flex gap-3 py-3">
                {index < steps.length - 1 ? (
                  <span className={`absolute left-[11px] top-9 h-7 w-px ${step.done ? 'bg-[hsl(var(--primary)/.55)]' : 'bg-[hsl(var(--card)/.12)]'}`} />
                ) : null}
                <div className={`relative z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[10px] font-semibold ${
                  step.done ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'border-[hsl(var(--card)/.2)] text-[hsl(var(--card)/.5)]'
                }`}>
                  {step.done ? <Check size={13} strokeWidth={2.8} /> : index + 1}
                </div>
                <div className="pt-[1px]">
                  <div className={`text-[13px] font-medium ${step.done ? 'text-[hsl(var(--card))]' : 'text-[hsl(var(--card)/.72)]'}`}>{step.label}</div>
                  <div className="mt-1 text-[11px] leading-4 text-[hsl(var(--card)/.38)]">{step.detail}</div>
                </div>
              </li>
            ))}
          </ol>
        </div>
        <div className="space-y-4">
          <div className="border-t border-[hsl(var(--card)/.1)] pt-5">
            <div className="flex items-start gap-2 text-[hsl(var(--card)/.55)]">
              <LockKeyhole size={14} className="mt-0.5 shrink-0 text-[hsl(var(--primary))]" />
              <p className="text-[11px] leading-[1.55]">Your files are read in the browser and sent only when you approve the commit.</p>
            </div>
          </div>
          <div className="font-mono text-[9px] uppercase tracking-[.14em] text-[hsl(var(--card)/.28)]">v1.0 / session protected</div>
        </div>
      </div>
    </aside>
  );
}

function ConnectionCard({
  connected,
  login,
  avatarUrl,
  isLoading,
  onConnect,
  onLogout,
  isConnecting,
  isLoggingOut,
}: {
  connected: boolean;
  login: string | null | undefined;
  avatarUrl: string | null | undefined;
  isLoading: boolean;
  onConnect: () => void;
  onLogout: () => void;
  isConnecting: boolean;
  isLoggingOut: boolean;
}) {
  if (isLoading) {
    return (
      <div className="flex animate-pulse items-center justify-between gap-4 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-[hsl(var(--muted))]" />
          <div className="space-y-2"><div className="h-3 w-32 rounded bg-[hsl(var(--muted))]" /><div className="h-2 w-44 rounded bg-[hsl(var(--muted))]" /></div>
        </div>
        <div className="h-9 w-24 rounded-lg bg-[hsl(var(--muted))]" />
      </div>
    );
  }

  return (
    <div data-testid="card-github-connection" className={`group flex flex-col gap-4 rounded-2xl border p-4 transition-colors sm:flex-row sm:items-center sm:justify-between ${
      connected ? 'border-[hsl(var(--primary)/.65)] bg-[hsl(var(--primary)/.13)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card))]'
    }`}>
      <div className="flex items-center gap-3">
        {connected && avatarUrl ? (
          <img data-testid="img-github-avatar" src={avatarUrl} alt="" className="h-10 w-10 rounded-xl border border-[hsl(var(--primary)/.55)]" />
        ) : (
          <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${connected ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : 'bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))]'}`}>
            {connected ? <CheckCircle2 size={19} /> : <GithubMark size={19} />}
          </div>
        )}
        <div>
          <div className="flex items-center gap-2 text-[13px] font-semibold">
            <span data-testid="status-github-connection">{connected ? `Connected as ${login ?? 'GitHub user'}` : 'GitHub is not connected'}</span>
            <StatusDot tone={connected ? 'good' : 'muted'} />
          </div>
          <p className="mt-1 text-[11px] leading-4 text-[hsl(var(--muted-foreground))]">
            {connected ? 'Easy Upload can see repositories you choose.' : 'Connect to browse repositories and send commits.'}
          </p>
        </div>
      </div>
      {connected ? (
        <button data-testid="button-disconnect-github" type="button" onClick={onLogout} disabled={isLoggingOut} className="inline-flex h-9 items-center justify-center gap-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-3 text-xs font-medium transition-colors hover:bg-[hsl(var(--muted))] disabled:opacity-60">
          {isLoggingOut ? <Loader2 size={14} className="animate-spin" /> : <LogOut size={14} />}
          Disconnect
        </button>
      ) : (
        <button data-testid="button-connect-github" type="button" onClick={onConnect} disabled={isConnecting} className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[hsl(var(--secondary))] px-4 text-xs font-semibold text-[hsl(var(--secondary-foreground))] shadow-sm transition-transform hover:-translate-y-0.5 disabled:opacity-60">
          {isConnecting ? <Loader2 size={14} className="animate-spin" /> : <GithubMark size={15} />}
          Connect GitHub
          {!isConnecting ? <ArrowUpRight size={14} /> : null}
        </button>
      )}
    </div>
  );
}

function RepositoryPanel({
  connected,
  repositories,
  isLoading,
  error,
  selectedRepository,
  repositoryUrl,
  branch,
  onRepositoryChange,
  onUrlChange,
  onBranchChange,
  onRetry,
  onCreateRepository,
  isCreatingRepository,
}: {
  connected: boolean;
  repositories: GithubRepository[];
  isLoading: boolean;
  error: unknown;
  selectedRepository: GithubRepository | undefined;
  repositoryUrl: string;
  branch: string;
  onRepositoryChange: (repository: GithubRepository) => void;
  onUrlChange: (value: string) => void;
  onBranchChange: (value: string) => void;
  onRetry: () => void;
  onCreateRepository: (input: GithubCreateRepositoryInput) => Promise<void>;
  isCreatingRepository: boolean;
}) {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newRepositoryName, setNewRepositoryName] = useState('');
  const [newRepositoryDescription, setNewRepositoryDescription] = useState('');
  const [newRepositoryPrivate, setNewRepositoryPrivate] = useState(true);
  const [createError, setCreateError] = useState<string | null>(null);

  const handleCreateSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!newRepositoryName.trim()) {
      setCreateError('Add a repository name before creating it.');
      return;
    }
    setCreateError(null);
    try {
      await onCreateRepository({
        name: newRepositoryName.trim(),
        description: newRepositoryDescription.trim(),
        private: newRepositoryPrivate,
      });
      setNewRepositoryName('');
      setNewRepositoryDescription('');
      setNewRepositoryPrivate(true);
      setIsCreateOpen(false);
    } catch (error) {
      setCreateError(getErrorMessage(error, 'GitHub could not create this repository.'));
    }
  };

  return (
    <section className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[0_8px_30px_-24px_hsl(var(--foreground)/.3)] sm:p-6">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]"><span className="text-[hsl(var(--accent))]">02</span> Destination</div>
          <h2 className="font-display text-xl font-semibold tracking-[-.04em]">Where should this land?</h2>
          <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Pick a repository, or paste a GitHub URL as a fallback.</p>
        </div>
        <div className="hidden h-9 w-9 items-center justify-center rounded-xl bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] sm:flex"><Link2 size={17} /></div>
      </div>

      {connected && isLoading ? (
        <div data-testid="status-repositories-loading" className="grid gap-2 sm:grid-cols-2">
          {[1, 2].map((item) => <div key={item} className="h-14 animate-pulse rounded-xl bg-[hsl(var(--muted))]" />)}
        </div>
      ) : connected && error ? (
        <div data-testid="status-repositories-error" className="flex items-center justify-between gap-3 rounded-xl border border-[hsl(var(--accent)/.45)] bg-[hsl(var(--accent)/.10)] p-3 text-xs">
          <div className="flex items-start gap-2"><AlertCircle size={15} className="mt-0.5 text-[hsl(var(--accent))]" /><span>Repositories could not be loaded. You can still paste a repository URL below.</span></div>
          <button data-testid="button-retry-repositories" type="button" onClick={onRetry} className="shrink-0 rounded-md p-1.5 hover:bg-[hsl(var(--accent)/.15)]" aria-label="Retry loading repositories"><RefreshCw size={14} /></button>
        </div>
      ) : connected && repositories.length === 0 ? (
        <div data-testid="status-repositories-empty" className="rounded-xl border border-dashed border-[hsl(var(--border))] bg-[hsl(var(--muted)/.42)] p-4 text-center">
          <FolderOpen size={18} className="mx-auto mb-2 text-[hsl(var(--muted-foreground))]" />
          <p className="text-xs font-medium">No repositories returned</p>
          <p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">Paste a GitHub URL below to continue.</p>
        </div>
      ) : null}

      {connected && repositories.length > 0 ? (
        <label className="mt-3 block">
          <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Your repositories</span>
          <div className="relative">
            <select
              data-testid="select-repository"
              value={selectedRepository?.id ?? ''}
              onChange={(event) => {
                const next = repositories.find((repo) => String(repo.id) === event.target.value);
                if (next) onRepositoryChange(next);
              }}
              className="h-11 w-full appearance-none rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 pr-10 text-sm outline-none transition-colors focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.18)]"
            >
              <option value="">Choose a repository…</option>
              {repositories.map((repo) => <option key={repo.id} value={repo.id}>{repo.fullName}{repo.private ? ' · private' : ''}</option>)}
            </select>
            <ChevronDown size={16} className="pointer-events-none absolute right-3 top-3.5 text-[hsl(var(--muted-foreground))]" />
          </div>
        </label>
      ) : null}

      {connected ? (
        <div className="mt-4">
          <button
            data-testid="button-toggle-create-repository"
            type="button"
            onClick={() => {
              setIsCreateOpen((open) => !open);
              setCreateError(null);
            }}
            className="inline-flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2 text-xs font-semibold transition-colors hover:border-[hsl(var(--primary)/.6)] hover:bg-[hsl(var(--muted)/.55)]"
          >
            <Plus size={14} />
            {isCreateOpen ? 'Cancel' : 'Create new repository'}
          </button>
        </div>
      ) : null}

      {connected && isCreateOpen ? (
        <form onSubmit={(event) => void handleCreateSubmit(event)} className="mt-4 rounded-xl border border-[hsl(var(--primary)/.35)] bg-[hsl(var(--primary)/.06)] p-4">
          <div className="mb-3">
            <h3 className="text-sm font-semibold">Create a new repository</h3>
            <p className="mt-1 text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">It starts with a README so you can upload files immediately.</p>
          </div>
          <label className="block">
            <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Repository name</span>
            <input data-testid="input-new-repository-name" value={newRepositoryName} onChange={(event) => setNewRepositoryName(event.target.value)} placeholder="my-new-project" autoComplete="off" className="h-10 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.18)]" />
          </label>
          <label className="mt-3 block">
            <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Description <span className="font-normal text-[hsl(var(--muted-foreground)/.7)]">optional</span></span>
            <input data-testid="input-new-repository-description" value={newRepositoryDescription} onChange={(event) => setNewRepositoryDescription(event.target.value)} placeholder="What is this project about?" className="h-10 w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.18)]" />
          </label>
          <label className="mt-3 flex items-center gap-2 text-xs">
            <input data-testid="checkbox-new-repository-private" type="checkbox" checked={newRepositoryPrivate} onChange={(event) => setNewRepositoryPrivate(event.target.checked)} className="h-4 w-4 accent-[hsl(var(--primary))]" />
            <span>Keep repository private</span>
          </label>
          {createError ? <div data-testid="status-create-repository-error" role="alert" className="mt-3 rounded-lg border border-[hsl(var(--destructive)/.45)] bg-[hsl(var(--destructive)/.08)] p-2.5 text-[11px] text-[hsl(var(--destructive))]">{createError}</div> : null}
          <button data-testid="button-create-repository" type="submit" disabled={isCreatingRepository || !newRepositoryName.trim()} className="mt-4 inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-[hsl(var(--foreground))] px-4 text-xs font-semibold text-[hsl(var(--background))] transition-opacity disabled:cursor-not-allowed disabled:opacity-50">
            {isCreatingRepository ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
            {isCreatingRepository ? 'Creating repository…' : 'Create repository'}
          </button>
        </form>
      ) : null}

      <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_170px]">
        <label className="block">
          <span className="mb-2 flex items-center gap-1.5 text-[11px] font-medium text-[hsl(var(--muted-foreground))]"><span>Repository URL</span><span className="font-normal text-[hsl(var(--muted-foreground)/.7)]">required</span></span>
          <div className="relative">
            <Link2 size={15} className="pointer-events-none absolute left-3 top-3.5 text-[hsl(var(--muted-foreground))]" />
            <input data-testid="input-repository-url" value={repositoryUrl} onChange={(event) => onUrlChange(event.target.value)} placeholder="https://github.com/owner/repository" className="h-11 w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] pl-9 pr-3 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.18)]" />
          </div>
        </label>
        <label className="block">
          <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Branch</span>
          <input data-testid="input-branch" value={branch} onChange={(event) => onBranchChange(event.target.value)} placeholder="main" className="h-11 w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.18)]" />
        </label>
      </div>
      {selectedRepository ? (
        <a data-testid="link-open-repository" href={selectedRepository.htmlUrl} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-medium text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--foreground))]">
          {selectedRepository.private ? <LockKeyhole size={12} /> : <ExternalLink size={12} />}
          {selectedRepository.private ? 'Private repository' : 'Open repository on GitHub'}
        </a>
      ) : null}
    </section>
  );
}

function FileStagingPanel({
  files,
  onFiles,
  onRemove,
  onClear,
}: {
  files: SelectedFile[];
  onFiles: (files: FileList | File[]) => void;
  onRemove: (path: string) => void;
  onClear: () => void;
}) {
  const [isDragging, setIsDragging] = useState(false);
  const totalSize = files.reduce((total, file) => total + file.size, 0);

  return (
    <section className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[0_8px_30px_-24px_hsl(var(--foreground)/.3)] sm:p-6">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]"><span className="text-[hsl(var(--accent))]">03</span> Files</div>
          <h2 className="font-display text-xl font-semibold tracking-[-.04em]">Stage what you want to send</h2>
          <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Folder paths stay exactly as they appear in your browser.</p>
        </div>
        {files.length > 0 ? <button data-testid="button-clear-files" type="button" onClick={onClear} className="text-[11px] font-medium text-[hsl(var(--muted-foreground))] underline-offset-4 hover:text-[hsl(var(--destructive))] hover:underline">Clear all</button> : null}
      </div>

      <div
        data-testid="dropzone-files"
        onDragEnter={(event) => { event.preventDefault(); setIsDragging(true); }}
        onDragOver={(event) => event.preventDefault()}
        onDragLeave={(event) => { if (event.currentTarget === event.target) setIsDragging(false); }}
        onDrop={(event) => { event.preventDefault(); setIsDragging(false); onFiles(event.dataTransfer.files); }}
        className={`grid gap-3 rounded-2xl border border-dashed p-4 transition-colors sm:grid-cols-2 ${isDragging ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary)/.12)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--muted)/.36)]'}`}
      >
        <label data-testid="label-select-files" className="group flex cursor-pointer items-center gap-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3 transition-transform hover:-translate-y-0.5 hover:border-[hsl(var(--primary)/.75)]">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[hsl(var(--primary)/.18)] text-[hsl(var(--foreground))]"><FileCode2 size={18} /></span>
          <span><span className="block text-xs font-semibold">Choose files</span><span className="mt-0.5 block text-[10px] text-[hsl(var(--muted-foreground))]">Any file type</span></span>
          <input data-testid="input-files" type="file" multiple className="sr-only" onChange={(event) => { if (event.target.files) onFiles(event.target.files); event.currentTarget.value = ''; }} />
        </label>
        <label data-testid="label-select-folder" className="group flex cursor-pointer items-center gap-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3 transition-transform hover:-translate-y-0.5 hover:border-[hsl(var(--primary)/.75)]">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[hsl(var(--accent)/.17)] text-[hsl(var(--foreground))]"><FolderOpen size={18} /></span>
          <span><span className="block text-xs font-semibold">Choose a folder</span><span className="mt-0.5 block text-[10px] text-[hsl(var(--muted-foreground))]">Paths preserved</span></span>
          <input data-testid="input-folder" type="file" multiple className="sr-only" {...folderInputProps} onChange={(event) => { if (event.target.files) onFiles(event.target.files); event.currentTarget.value = ''; }} />
        </label>
        <div className="flex items-center justify-center gap-2 text-[10px] text-[hsl(var(--muted-foreground))] sm:col-span-2"><UploadCloud size={13} /> or drag files here</div>
      </div>

      {files.length === 0 ? (
        <div data-testid="status-files-empty" className="grid place-items-center py-8 text-center">
          <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--muted)/.55)] text-[hsl(var(--muted-foreground))]"><FileText size={19} /></div>
          <p className="text-xs font-medium">Nothing staged yet</p>
          <p className="mt-1 max-w-[250px] text-[11px] leading-4 text-[hsl(var(--muted-foreground))]">Start with one file, or select a folder to keep its nested structure.</p>
        </div>
      ) : (
        <div data-testid="status-files-ready" className="mt-4">
          <div className="mb-2 flex items-center justify-between font-mono text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]"><span>{files.length} {files.length === 1 ? 'file' : 'files'} staged</span><span>{formatBytes(totalSize)}</span></div>
          <ul className="max-h-56 divide-y divide-[hsl(var(--border))] overflow-auto rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))]">
            {files.map((file) => (
              <li data-testid={`row-staged-file-${file.path}`} key={file.path} className="flex items-center gap-3 px-3 py-2.5">
                <FileCode2 size={15} className="shrink-0 text-[hsl(var(--muted-foreground))]" />
                <span className="min-w-0 flex-1 truncate font-mono text-[11px]" title={file.path}>{file.path}</span>
                <span className="shrink-0 font-mono text-[10px] text-[hsl(var(--muted-foreground))]">{formatBytes(file.size)}</span>
                <button data-testid={`button-remove-file-${file.path}`} type="button" onClick={() => onRemove(file.path)} className="rounded-md p-1 text-[hsl(var(--muted-foreground))] transition-colors hover:bg-[hsl(var(--destructive)/.1)] hover:text-[hsl(var(--destructive))]" aria-label={`Remove ${file.path}`}><X size={14} /></button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}

function CommitPanel({
  commitMessage,
  targetPath,
  onCommitMessageChange,
  onTargetPathChange,
  onUpload,
  canUpload,
  isUploading,
}: {
  commitMessage: string;
  targetPath: string;
  onCommitMessageChange: (value: string) => void;
  onTargetPathChange: (value: string) => void;
  onUpload: () => void;
  canUpload: boolean;
  isUploading: boolean;
}) {
  return (
    <section className="rounded-2xl border border-[hsl(var(--foreground))] bg-[hsl(var(--secondary))] p-5 text-[hsl(var(--secondary-foreground))] shadow-[0_14px_40px_-24px_hsl(var(--foreground)/.55)] sm:p-6">
      <div className="mb-5 flex items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><Code2 size={18} /></div>
        <div>
          <div className="mb-1 font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--card)/.45)]">04 / commit</div>
          <h2 className="font-display text-xl font-semibold tracking-[-.04em]">Ready when you are.</h2>
          <p className="mt-1 text-xs leading-5 text-[hsl(var(--card)/.55)]">One commit. Clear message. No token handling.</p>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-[1fr_190px]">
        <label className="block">
          <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--card)/.65)]">Commit message</span>
          <input data-testid="input-commit-message" value={commitMessage} onChange={(event) => onCommitMessageChange(event.target.value)} placeholder="Add files via Easy Upload" className="h-11 w-full rounded-xl border border-[hsl(var(--card)/.15)] bg-[hsl(var(--card)/.07)] px-3 text-sm text-[hsl(var(--card))] outline-none transition-colors placeholder:text-[hsl(var(--card)/.32)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.22)]" />
        </label>
        <label className="block">
          <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--card)/.65)]">Target folder <span className="font-normal text-[hsl(var(--card)/.35)]">optional</span></span>
          <input data-testid="input-target-path" value={targetPath} onChange={(event) => onTargetPathChange(event.target.value)} placeholder="e.g. assets/" className="h-11 w-full rounded-xl border border-[hsl(var(--card)/.15)] bg-[hsl(var(--card)/.07)] px-3 font-mono text-sm text-[hsl(var(--card))] outline-none transition-colors placeholder:text-[hsl(var(--card)/.32)] focus:border-[hsl(var(--primary))] focus:ring-2 focus:ring-[hsl(var(--primary)/.22)]" />
        </label>
      </div>
      <div className="mt-5 flex flex-col items-start justify-between gap-4 border-t border-[hsl(var(--card)/.1)] pt-4 sm:flex-row sm:items-center">
        <div className="flex items-start gap-2 text-[11px] leading-4 text-[hsl(var(--card)/.48)]"><ShieldCheck size={14} className="mt-0.5 shrink-0 text-[hsl(var(--primary))]" /><span>Browser-relative paths are retained.<br />Your files are never stored by this page.</span></div>
        <button data-testid="button-upload-to-github" type="button" onClick={onUpload} disabled={!canUpload || isUploading} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 text-xs font-bold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45 sm:w-auto">
          {isUploading ? <><Loader2 size={15} className="animate-spin" /> Sending commit…</> : <><CloudUpload size={15} /> Send commit</>}
        </button>
      </div>
    </section>
  );
}

function UploadResultCard({ result }: { result: GithubUploadResult }) {
  const isPartial = result.failed > 0 && result.succeeded > 0;
  const isFailure = result.succeeded === 0 || (result.total > 0 && result.failed === result.total);
  return (
    <section data-testid="card-upload-result" className={`animate-rise-in rounded-2xl border p-5 sm:p-6 ${isFailure ? 'border-[hsl(var(--destructive)/.5)] bg-[hsl(var(--destructive)/.08)]' : isPartial ? 'border-[hsl(var(--accent)/.55)] bg-[hsl(var(--accent)/.10)]' : 'border-[hsl(var(--primary)/.65)] bg-[hsl(var(--primary)/.13)]'}`}>
      <div className="flex items-start gap-3">
        <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${isFailure ? 'bg-[hsl(var(--destructive)/.14)] text-[hsl(var(--destructive))]' : isPartial ? 'bg-[hsl(var(--accent)/.18)] text-[hsl(var(--accent-foreground))]' : 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]'}`}>
          {isFailure ? <XCircle size={20} /> : isPartial ? <AlertCircle size={20} /> : <CheckCircle2 size={20} />}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <h2 className="font-display text-lg font-semibold tracking-[-.03em]">{isFailure ? 'Commit needs attention' : isPartial ? 'Commit sent with some misses' : 'Commit sent successfully'}</h2>
            <span className="font-mono text-[10px] uppercase tracking-[.13em] text-[hsl(var(--muted-foreground))]">{result.succeeded}/{result.total} succeeded</span>
          </div>
          <p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{result.repository} · {result.branch}</p>
          {result.commitSha ? <div className="mt-3 inline-flex max-w-full items-center gap-2 rounded-lg bg-[hsl(var(--background)/.6)] px-2.5 py-1.5 font-mono text-[10px] text-[hsl(var(--muted-foreground))]"><span className="truncate">{result.commitSha}</span><button data-testid="button-copy-commit-sha" type="button" onClick={() => void navigator.clipboard?.writeText(result.commitSha ?? '')} className="shrink-0 rounded p-0.5 hover:bg-[hsl(var(--muted))]" aria-label="Copy commit SHA"><Copy size={12} /></button></div> : null}
        </div>
      </div>
      <div className="mt-5 overflow-hidden rounded-xl border border-[hsl(var(--border)/.7)] bg-[hsl(var(--background)/.52)]">
        <div className="grid grid-cols-[1fr_auto] border-b border-[hsl(var(--border)/.7)] px-3 py-2 font-mono text-[9px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]"><span>File</span><span>Status</span></div>
        <ul className="max-h-48 divide-y divide-[hsl(var(--border)/.65)] overflow-auto">
          {result.items.map((item, index) => <li data-testid={`row-upload-result-${index}`} key={`${item.path}-${index}`} className="grid grid-cols-[1fr_auto] items-center gap-3 px-3 py-2 text-[11px]"><span className="min-w-0 truncate font-mono" title={item.path}>{item.path}</span><span className={`inline-flex items-center gap-1 text-[10px] font-semibold ${item.status === 'failed' ? 'text-[hsl(var(--destructive))]' : 'text-[hsl(var(--chart-2))]'}`}>{item.status === 'failed' ? <XCircle size={12} /> : <Check size={12} />}{item.status}</span></li>)}
        </ul>
      </div>
    </section>
  );
}

function EmptyRepositoryPage() {
  const [selectedRepositoryId, setSelectedRepositoryId] = useState<number | null>(null);
  const [branch, setBranch] = useState('main');
  const [confirmation, setConfirmation] = useState('');
  const [acknowledged, setAcknowledged] = useState(false);
  const [result, setResult] = useState<GithubEmptyRepositoryResult | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  const authQuery = useGetGithubAuthStatus({ query: { queryKey: getGetGithubAuthStatusQueryKey() } });
  const repositoryQuery = useListGithubRepositories({
    query: { enabled: Boolean(authQuery.data?.connected), queryKey: getListGithubRepositoriesQueryKey() },
  });
  const emptyMutation = useEmptyGithubRepository();
  const connected = Boolean(authQuery.data?.connected);
  const repositories = repositoryQuery.data ?? [];
  const selectedRepository = repositories.find((repository) => repository.id === selectedRepositoryId);

  const handleConnect = () => {
    setIsConnecting(true);
    const redirectUri = `${window.location.origin}/api/github/auth/callback`;
    window.location.assign(`/api/github/auth/start?redirect_uri=${encodeURIComponent(redirectUri)}`);
  };

  const handleEmptyRepository = async () => {
    setFormError(null);
    setResult(null);
    if (!connected) {
      setFormError('Connect GitHub before emptying a repository.');
      return;
    }
    if (!selectedRepository) {
      setFormError('Choose a repository before continuing.');
      return;
    }
    if (!branch.trim()) {
      setFormError('Enter the branch you want to empty.');
      return;
    }
    if (!acknowledged) {
      setFormError('Confirm that you understand the files on this branch will be deleted.');
      return;
    }
    if (confirmation.trim().toUpperCase() !== 'EMPTY') {
      setFormError('Type EMPTY exactly to confirm the action.');
      return;
    }

    try {
      const emptyResult = await emptyMutation.mutateAsync({
        data: {
          repositoryUrl: selectedRepository.htmlUrl,
          branch: branch.trim(),
          confirmation: confirmation.trim(),
        },
      });
      setResult(emptyResult);
      setConfirmation('');
      setAcknowledged(false);
      await repositoryQuery.refetch();
    } catch (error) {
      setFormError(getErrorMessage(error, 'GitHub could not empty this branch. Check branch protection and try again.'));
    }
  };

  return (
    <div className="app-noise min-h-[100dvh] bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
      <header className="sticky top-0 z-40 border-b border-[hsl(var(--border)/.82)] bg-[hsl(var(--background)/.92)] backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-5 sm:px-8">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center">
              <img src={easyUploadLogo} alt="Easy Upload" className="h-8 w-[132px] object-contain object-left" />
            </Link>
            <span className="hidden text-[hsl(var(--border))] sm:inline">/</span>
            <span className="hidden font-medium text-[11px] sm:inline">Empty repository</span>
          </div>
          <Link href="/" data-testid="link-back-to-upload" className="inline-flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2 text-[11px] font-semibold transition-colors hover:bg-[hsl(var(--muted)/.55)]">
            <ArrowLeft size={13} />
            Back to upload
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-[900px] px-5 py-8 sm:px-8 sm:py-12">
        <div className="animate-rise-in mb-8">
          <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--destructive))]"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--destructive))]" /> Danger zone</div>
          <h1 data-testid="text-empty-page-title" className="text-balance font-display text-[clamp(2.25rem,6vw,4rem)] font-semibold leading-[.94] tracking-[-.065em]">Empty a branch.<br /><span className="text-[hsl(var(--muted-foreground))]">Keep the repository.</span></h1>
          <p className="mt-4 max-w-[590px] text-sm leading-6 text-[hsl(var(--muted-foreground))]">Remove every file from one selected branch in a single commit. The repository, its settings, and all other branches remain untouched.</p>
        </div>

        {!connected ? (
          <section className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-[0_8px_30px_-24px_hsl(var(--foreground)/.3)] sm:p-6">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))]"><GithubMark size={19} /></div>
              <div className="flex-1">
                <h2 className="text-sm font-semibold">GitHub is not connected</h2>
                <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">Connect your account to choose a repository and branch.</p>
              </div>
              <button data-testid="button-connect-empty-page" type="button" onClick={handleConnect} disabled={isConnecting} className="inline-flex items-center gap-2 rounded-lg bg-[hsl(var(--secondary))] px-3 py-2 text-[11px] font-semibold text-[hsl(var(--secondary-foreground))] disabled:opacity-60">
                {isConnecting ? <Loader2 size={13} className="animate-spin" /> : <GithubMark size={13} />}
                Connect
              </button>
            </div>
          </section>
        ) : (
          <section className="rounded-2xl border border-[hsl(var(--destructive)/.5)] bg-[hsl(var(--card))] p-5 shadow-[0_8px_30px_-24px_hsl(var(--foreground)/.3)] sm:p-6">
            <div className="mb-5 flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]"><Trash2 size={19} /></div>
              <div>
                <div className="mb-1 font-mono text-[10px] uppercase tracking-[.15em] text-[hsl(var(--destructive))]">Permanent file removal</div>
                <h2 className="text-lg font-semibold tracking-[-.03em]">Choose what to empty</h2>
                <p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">This keeps the repository itself. Only the selected branch’s current files are removed.</p>
              </div>
            </div>

            {repositoryQuery.isLoading ? (
              <div data-testid="status-empty-repositories-loading" className="h-12 animate-pulse rounded-xl bg-[hsl(var(--muted))]" />
            ) : repositoryQuery.error ? (
              <div data-testid="status-empty-repositories-error" role="alert" className="flex items-center justify-between gap-3 rounded-xl border border-[hsl(var(--destructive)/.4)] bg-[hsl(var(--destructive)/.08)] p-3 text-xs">
                <span>Repositories could not be loaded.</span>
                <button type="button" onClick={() => void repositoryQuery.refetch()} className="rounded-md p-1.5 hover:bg-[hsl(var(--destructive)/.12)]" aria-label="Retry loading repositories"><RefreshCw size={14} /></button>
              </div>
            ) : (
              <>
                <label className="block">
                  <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Repository</span>
                  <div className="relative">
                    <select
                      data-testid="select-empty-repository"
                      value={selectedRepositoryId ?? ''}
                      onChange={(event) => {
                        const next = repositories.find((repository) => String(repository.id) === event.target.value);
                        if (next) {
                          setSelectedRepositoryId(next.id);
                          setBranch(next.defaultBranch);
                          setFormError(null);
                        }
                      }}
                      className="h-11 w-full appearance-none rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 pr-10 text-sm outline-none transition-colors focus:border-[hsl(var(--destructive))] focus:ring-2 focus:ring-[hsl(var(--destructive)/.15)]"
                    >
                      <option value="">Choose a repository…</option>
                      {repositories.map((repository) => <option key={repository.id} value={repository.id}>{repository.fullName}{repository.private ? ' · private' : ''}</option>)}
                    </select>
                    <ChevronDown size={16} className="pointer-events-none absolute right-3 top-3.5 text-[hsl(var(--muted-foreground))]" />
                  </div>
                </label>
                <label className="mt-4 block">
                  <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Branch</span>
                  <input data-testid="input-empty-branch" value={branch} onChange={(event) => { setBranch(event.target.value); setFormError(null); }} placeholder="main" className="h-11 w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--destructive))] focus:ring-2 focus:ring-[hsl(var(--destructive)/.15)]" />
                </label>
                <div className="mt-5 rounded-xl border border-[hsl(var(--destructive)/.35)] bg-[hsl(var(--destructive)/.07)] p-3.5 text-xs leading-5 text-[hsl(var(--muted-foreground))]">
                  <div className="flex items-start gap-2"><AlertCircle size={15} className="mt-0.5 shrink-0 text-[hsl(var(--destructive))]" /><span><strong className="text-[hsl(var(--foreground))]">This cannot be undone from Easy Upload.</strong> The current branch files will be replaced by an empty tree commit. Other branches are not changed.</span></div>
                </div>
                <label className="mt-4 flex items-start gap-2 text-xs leading-5">
                  <input data-testid="checkbox-empty-acknowledgement" type="checkbox" checked={acknowledged} onChange={(event) => { setAcknowledged(event.target.checked); setFormError(null); }} className="mt-1 h-4 w-4 accent-[hsl(var(--destructive))]" />
                  <span>I understand that all files on the selected branch will be deleted.</span>
                </label>
                <label className="mt-4 block">
                  <span className="mb-2 block text-[11px] font-medium text-[hsl(var(--muted-foreground))]">Type <code className="rounded bg-[hsl(var(--muted))] px-1 py-0.5 font-mono text-[10px]">EMPTY</code> to confirm</span>
                  <input data-testid="input-empty-confirmation" value={confirmation} onChange={(event) => { setConfirmation(event.target.value); setFormError(null); }} placeholder="EMPTY" autoComplete="off" className="h-11 w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 font-mono text-sm uppercase outline-none transition-colors placeholder:normal-case placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--destructive))] focus:ring-2 focus:ring-[hsl(var(--destructive)/.15)]" />
                </label>
                {formError ? <div data-testid="status-empty-error" role="alert" className="mt-4 rounded-xl border border-[hsl(var(--destructive)/.45)] bg-[hsl(var(--destructive)/.08)] p-3 text-xs text-[hsl(var(--destructive))]">{formError}</div> : null}
                <button data-testid="button-empty-repository" type="button" onClick={() => void handleEmptyRepository()} disabled={emptyMutation.isPending || !selectedRepository || !acknowledged || confirmation.trim().toUpperCase() !== 'EMPTY'} className="mt-5 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[hsl(var(--destructive))] px-5 text-xs font-bold text-[hsl(var(--destructive-foreground))] transition-opacity disabled:cursor-not-allowed disabled:opacity-45">
                  {emptyMutation.isPending ? <Loader2 size={15} className="animate-spin" /> : <Trash2 size={15} />}
                  {emptyMutation.isPending ? 'Emptying branch…' : 'Empty selected branch'}
                </button>
              </>
            )}
          </section>
        )}

        {result ? (
          <section data-testid="card-empty-result" className="mt-5 rounded-2xl border border-[hsl(var(--primary)/.65)] bg-[hsl(var(--primary)/.13)] p-5 sm:p-6">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><CheckCircle2 size={20} /></div>
              <div>
                <h2 className="font-display text-lg font-semibold tracking-[-.03em]">Branch emptied successfully</h2>
                <p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{result.repository} · {result.branch}</p>
                <p className="mt-3 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{result.deletedCount} top-level item{result.deletedCount === 1 ? '' : 's'} removed in one commit.</p>
                {result.commitSha ? <div className="mt-3 inline-flex max-w-full items-center gap-2 rounded-lg bg-[hsl(var(--background)/.6)] px-2.5 py-1.5 font-mono text-[10px] text-[hsl(var(--muted-foreground))]"><span className="truncate">{result.commitSha}</span><button type="button" onClick={() => void navigator.clipboard?.writeText(result.commitSha ?? '')} className="shrink-0 rounded p-0.5 hover:bg-[hsl(var(--muted))]" aria-label="Copy empty commit SHA"><Copy size={12} /></button></div> : null}
              </div>
            </div>
          </section>
        ) : null}

        <footer className="mt-10 flex items-center gap-2 border-t border-[hsl(var(--border))] pt-5 text-[10px] text-[hsl(var(--muted-foreground))]"><ShieldCheck size={13} /><span>Easy Upload never deletes the repository itself or changes other branches.</span></footer>
      </main>
    </div>
  );
}

function Home() {
  const [authReturn, setAuthReturn] = useState<'connected' | 'error' | null>(null);
  const [repositoryUrl, setRepositoryUrl] = useState('');
  const [selectedRepositoryId, setSelectedRepositoryId] = useState<number | null>(null);
  const [branch, setBranch] = useState('main');
  const [targetPath, setTargetPath] = useState('');
  const [commitMessage, setCommitMessage] = useState('Add files via Easy Upload');
  const [files, setFiles] = useState<SelectedFile[]>([]);
  const [uploadResult, setUploadResult] = useState<GithubUploadResult | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [encodingCount, setEncodingCount] = useState(0);

  useEffect(() => {
    const url = new URL(window.location.href);
    const value = url.searchParams.get('github');
    if (value === 'connected' || value === 'error') {
      setAuthReturn(value);
      url.searchParams.delete('github');
      window.history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
    }
  }, []);

  const authQuery = useGetGithubAuthStatus({ query: { queryKey: getGetGithubAuthStatusQueryKey() } });
  const healthQuery = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), staleTime: 30000 } });
  const connected = Boolean(authQuery.data?.connected);
  const repositoryQuery = useListGithubRepositories({
    query: { enabled: connected, queryKey: getListGithubRepositoriesQueryKey() },
  });
  const logoutMutation = useLogoutGithub();
  const createRepositoryMutation = useCreateGithubRepository();
  const uploadMutation = useUploadToGithub();
  const repositories = repositoryQuery.data ?? [];
  const selectedRepository = repositories.find((repository) => repository.id === selectedRepositoryId);
  const visibleAuthReturn = connected ? 'connected' : authReturn;

  const handleRepositoryChange = (repository: GithubRepository) => {
    setSelectedRepositoryId(repository.id);
    setRepositoryUrl(repository.htmlUrl);
    setBranch(repository.defaultBranch);
    setFormError(null);
  };

  const handleCreateRepository = async (input: GithubCreateRepositoryInput) => {
    const repository = await createRepositoryMutation.mutateAsync({ data: input });
    handleRepositoryChange(repository);
    await repositoryQuery.refetch();
  };

  const validRepositoryUrl = /^https:\/\/github\.com\/[^/\s]+\/[^/\s]+\/?$/.test(repositoryUrl.trim());
  const canUpload = connected && validRepositoryUrl && Boolean(branch.trim()) && Boolean(commitMessage.trim()) && files.length > 0 && !uploadMutation.isPending;
  const stepState = {
    connected,
    hasRepository: validRepositoryUrl && Boolean(branch.trim()),
    hasFiles: files.length > 0,
    hasResult: Boolean(uploadResult),
  };

  const addFiles = (incoming: FileList | File[]) => {
    const nextFiles = Array.from(incoming).map((file) => {
      const browserFile = file as BrowserFile;
      const browserPath = browserFile.webkitRelativePath?.trim();
      return { file, path: browserPath || file.name, size: file.size };
    });
    setFiles((current) => {
      const byPath = new Map(current.map((file) => [file.path, file]));
      nextFiles.forEach((file) => byPath.set(file.path, file));
      return Array.from(byPath.values());
    });
    setUploadResult(null);
    setFormError(null);
  };

  const handleConnect = () => {
    setIsConnecting(true);
    const redirectUri = `${window.location.origin}/api/github/auth/callback`;
    window.location.assign(`/api/github/auth/start?redirect_uri=${encodeURIComponent(redirectUri)}`);
  };

  const handleUpload = async () => {
    setFormError(null);
    setUploadResult(null);
    if (!connected) return setFormError('Connect GitHub before sending a commit.');
    if (!validRepositoryUrl) return setFormError('Enter a GitHub repository URL such as https://github.com/owner/repository.');
    if (!branch.trim()) return setFormError('Add a branch name before sending.');
    if (!commitMessage.trim()) return setFormError('Add a commit message before sending.');
    if (!files.length) return setFormError('Choose at least one file before sending.');

    try {
      setEncodingCount(0);
      const encodedFiles = await Promise.all(files.map(async (file) => {
        const contentBase64 = await readAsBase64(file.file);
        setEncodingCount((count) => count + 1);
        return { path: file.path, contentBase64, size: file.size };
      }));
      const result = await uploadMutation.mutateAsync({
        data: {
          repositoryUrl: repositoryUrl.trim(),
          targetPath: targetPath.trim(),
          branch: branch.trim(),
          commitMessage: commitMessage.trim(),
          files: encodedFiles,
        },
      });
      setUploadResult(result);
    } catch (error) {
      setFormError(getErrorMessage(error, 'GitHub could not accept this commit. Check the repository and branch, then try again.'));
    } finally {
      setEncodingCount(0);
    }
  };

  return (
    <div className="app-noise min-h-[100dvh] bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
      <header className="sticky top-0 z-40 border-b border-[hsl(var(--border)/.82)] bg-[hsl(var(--background)/.92)] backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-5 sm:px-8">
          <div className="flex items-center lg:hidden">
            <img src={easyUploadLogo} alt="Easy Upload" className="h-8 w-[132px] object-contain object-left" />
          </div>
          <div className="hidden items-center gap-4 lg:flex">
            <img src={easyUploadLogo} alt="Easy Upload" className="h-8 w-[132px] object-contain object-left" />
            <span className="text-[hsl(var(--border))]">/</span>
            <Link href="/" className="font-medium text-[11px] text-[hsl(var(--foreground))]">New upload</Link>
            <span className="text-[hsl(var(--border))]">/</span>
            <Link href="/empty-repository" className="font-medium text-[11px] text-[hsl(var(--muted-foreground))] transition-colors hover:text-[hsl(var(--foreground))]">Empty repository</Link>
          </div>
          <div className="flex items-center gap-4">
            <div data-testid="status-api-health" className="hidden items-center gap-2 text-[10px] text-[hsl(var(--muted-foreground))] sm:flex"><StatusDot tone={healthQuery.isError ? 'bad' : healthQuery.isLoading ? 'muted' : 'good'} /><span>{healthQuery.isError ? 'Service unavailable' : 'Transport online'}</span></div>
            {connected ? <div data-testid="text-header-login" className="flex items-center gap-2 border-l border-[hsl(var(--border))] pl-4 text-[11px] font-medium"><span className="hidden text-[hsl(var(--muted-foreground))] sm:inline">@{authQuery.data?.login}</span><GithubMark size={15} /></div> : null}
          </div>
        </div>
      </header>
      <div className="mx-auto flex max-w-[1440px]">
        <StepRail {...stepState} />
        <main className="min-w-0 flex-1 px-5 py-8 sm:px-8 sm:py-10">
          <div className="mx-auto max-w-[890px]">
            <div className="animate-rise-in mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
              <div>
                <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--accent-foreground))]"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" /> Developer workspace</div>
                <h1 data-testid="text-page-title" className="text-balance font-display text-[clamp(2.25rem,6vw,4rem)] font-semibold leading-[.94] tracking-[-.065em]">Send files.<br /><span className="text-[hsl(var(--muted-foreground))]">Keep your flow.</span></h1>
                <p className="mt-4 max-w-[480px] text-sm leading-6 text-[hsl(var(--muted-foreground))]">A quieter way to move files into GitHub. Choose a destination, stage a file or folder, then make one deliberate commit.</p>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:w-[196px]">
                <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.55)] p-3"><div className="font-mono text-[9px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">Mode</div><div className="mt-1 text-xs font-semibold">Browser-first</div></div>
                <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.55)] p-3"><div className="font-mono text-[9px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">Privacy</div><div className="mt-1 text-xs font-semibold">No tokens</div></div>
              </div>
            </div>

            {visibleAuthReturn ? (
              <div data-testid={`status-github-return-${visibleAuthReturn}`} className={`animate-sweep-in mb-5 flex items-start gap-3 rounded-xl border p-3.5 text-xs ${visibleAuthReturn === 'connected' ? 'border-[hsl(var(--primary)/.55)] bg-[hsl(var(--primary)/.12)]' : 'border-[hsl(var(--destructive)/.45)] bg-[hsl(var(--destructive)/.08)]'}`}>
                {visibleAuthReturn === 'connected' ? <CheckCircle2 size={16} className="mt-0.5 text-[hsl(var(--chart-2))]" /> : <AlertCircle size={16} className="mt-0.5 text-[hsl(var(--destructive))]" />}
                <div><div className="font-semibold">{visibleAuthReturn === 'connected' ? 'GitHub connected.' : 'GitHub connection did not complete.'}</div><div className="mt-0.5 text-[hsl(var(--muted-foreground))]">{visibleAuthReturn === 'connected' ? 'Your repositories are ready to choose below.' : 'Try connecting again. Your files and form state remain untouched.'}</div></div>
                <button data-testid="button-dismiss-auth-return" type="button" onClick={() => setAuthReturn(null)} className="ml-auto rounded p-1 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted)/.7)]" aria-label="Dismiss GitHub status"><X size={14} /></button>
              </div>
            ) : null}

            <div className="space-y-5">
              <div className="animate-rise-in delay-1">
                <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]"><span className="text-[hsl(var(--accent))]">01</span> Account</div>
             <ConnectionCard connected={connected} login={authQuery.data?.login} avatarUrl={authQuery.data?.avatarUrl} isLoading={authQuery.isLoading} onConnect={handleConnect} onLogout={() => logoutMutation.mutate(undefined, { onSuccess: () => { void authQuery.refetch(); void repositoryQuery.refetch(); } })} isConnecting={isConnecting} isLoggingOut={logoutMutation.isPending} />
              </div>

              <div className="animate-rise-in delay-2">
                <RepositoryPanel connected={connected} repositories={repositories} isLoading={repositoryQuery.isLoading} error={repositoryQuery.error} selectedRepository={selectedRepository} repositoryUrl={repositoryUrl} branch={branch} onRepositoryChange={handleRepositoryChange} onUrlChange={(value) => { setRepositoryUrl(value); setSelectedRepositoryId(null); setFormError(null); }} onBranchChange={(value) => { setBranch(value); setFormError(null); }} onRetry={() => void repositoryQuery.refetch()} onCreateRepository={handleCreateRepository} isCreatingRepository={createRepositoryMutation.isPending} />
              </div>

              <div className="animate-rise-in delay-3">
                <FileStagingPanel files={files} onFiles={addFiles} onRemove={(path) => { setFiles((current) => current.filter((file) => file.path !== path)); setUploadResult(null); }} onClear={() => { setFiles([]); setUploadResult(null); }} />
              </div>

              {formError ? <div data-testid="status-upload-error" role="alert" className="flex items-start gap-2 rounded-xl border border-[hsl(var(--destructive)/.45)] bg-[hsl(var(--destructive)/.08)] p-3.5 text-xs"><AlertCircle size={15} className="mt-0.5 shrink-0 text-[hsl(var(--destructive))]" /><span>{formError}</span></div> : null}

              <CommitPanel commitMessage={commitMessage} targetPath={targetPath} onCommitMessageChange={(value) => { setCommitMessage(value); setUploadResult(null); }} onTargetPathChange={(value) => { setTargetPath(value); setUploadResult(null); }} onUpload={() => void handleUpload()} canUpload={canUpload} isUploading={uploadMutation.isPending || encodingCount > 0} />

              {uploadMutation.isPending && encodingCount > 0 ? <div data-testid="status-upload-encoding" className="font-mono text-[10px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">Reading {encodingCount}/{files.length} files in your browser…</div> : null}
              {uploadResult ? <UploadResultCard result={uploadResult} /> : null}
            </div>

            <footer className="mt-10 flex flex-col gap-3 border-t border-[hsl(var(--border))] pt-5 text-[10px] text-[hsl(var(--muted-foreground))] sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2"><Info size={13} /><span>Easy Upload uses GitHub OAuth. We never ask for your personal access token.</span></div>
              <div className="font-mono uppercase tracking-[.12em]">Built for careful commits</div>
            </footer>
          </div>
        </main>
      </div>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/empty-repository" component={EmptyRepositoryPage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
