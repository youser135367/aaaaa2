import crypto from "node:crypto";
import { Router, type IRouter, type Request } from "express";
import {
  EmptyGithubRepositoryBody,
  EmptyGithubRepositoryResponse,
  GetGithubAuthStatusResponse,
  CreateGithubRepositoryBody,
  CreateGithubRepositoryResponse,
  ListGithubRepositoriesResponse,
  LogoutGithubResponse,
  UploadToGithubBody,
  UploadToGithubResponse,
} from "@workspace/api-zod";
import {
  createGithubBlob,
  createGithubCommit,
  createGithubContent,
  createGithubRef,
  createGithubRepository,
  getGithubTree,
  createGithubTree,
  getGithubRef,
  getGithubRepository,
  getGithubUser,
  listGithubRepositories,
  parseRepositoryUrl,
  updateGithubRef,
} from "../lib/github";

const router: IRouter = Router();
const githubTokenCookie = "easy_upload_github_token";
const githubStateCookie = "easy_upload_github_state";
const githubRedirectCookie = "easy_upload_github_redirect";

function cookieOptions(maxAge: number) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    signed: true,
    maxAge,
    path: "/",
  };
}

function getToken(req: Request) {
  return req.signedCookies?.[githubTokenCookie] as string | undefined;
}

function getOrigin(req: Request) {
  const forwardedProto = req.get("x-forwarded-proto")?.split(",")[0];
  const forwardedHost = req.get("x-forwarded-host")?.split(",")[0];
  const protocol = forwardedProto || req.protocol;
  const host = forwardedHost || req.get("host");
  return `${protocol}://${host}`;
}

function getSameOriginRedirect(req: Request) {
  const requestedRedirect =
    typeof req.query.redirect_uri === "string" ? req.query.redirect_uri : "";
  if (!requestedRedirect) return null;

  try {
    const callback = new URL(requestedRedirect);
    if (
      callback.origin !== getOrigin(req) ||
      callback.pathname !== "/api/github/auth/callback" ||
      !["http:", "https:"].includes(callback.protocol)
    ) {
      return null;
    }
    return callback.toString();
  } catch {
    return null;
  }
}

function errorMessage(data: unknown, fallback: string) {
  if (data && typeof data === "object" && "message" in data) {
    const message = (data as { message?: unknown }).message;
    if (typeof message === "string" && message) return message;
  }
  return fallback;
}

function githubErrorStatus(status: number) {
  if (status === 401) return 401;
  if (status === 404) return 404;
  return status >= 400 && status < 500 ? 400 : 502;
}

router.get("/github/auth/status", async (req, res) => {
  const token = getToken(req);
  if (!token) {
    res.json(GetGithubAuthStatusResponse.parse({ connected: false, login: null, avatarUrl: null }));
    return;
  }

  const result = await getGithubUser(token);
  if (!result.response.ok) {
    res.clearCookie(githubTokenCookie, { path: "/" });
    res.json(GetGithubAuthStatusResponse.parse({ connected: false, login: null, avatarUrl: null }));
    return;
  }

  res.json(
    GetGithubAuthStatusResponse.parse({
      connected: true,
      login: result.data.login,
      avatarUrl: result.data.avatar_url,
    }),
  );
});

router.get("/github/auth/start", (req, res) => {
  const clientId = process.env.GITHUB_CLIENT_ID;
  if (!clientId) {
    res.status(503).json({ error: "GitHub OAuth is not configured yet." });
    return;
  }

  const state = crypto.randomBytes(24).toString("hex");
  res.cookie(githubStateCookie, state, cookieOptions(10 * 60 * 1000));

  // Prefer the current browser origin. This prevents an old fixed
  // GITHUB_REDIRECT_URI from sending OAuth back to a previous deployment.
  // Only same-origin requested URLs are accepted, so this does not become an
  // open redirect.
  const callbackUrl =
    getSameOriginRedirect(req) ||
    process.env.GITHUB_REDIRECT_URI ||
    `${getOrigin(req)}/api/github/auth/callback`;
  let callback: URL;
  try {
    callback = new URL(callbackUrl);
  } catch {
    res.status(400).json({ error: "Invalid GitHub OAuth callback URL." });
    return;
  }
  if (!["http:", "https:"].includes(callback.protocol) || callback.pathname !== "/api/github/auth/callback") {
    res.status(400).json({ error: "Invalid GitHub OAuth callback URL." });
    return;
  }
  res.cookie(githubRedirectCookie, callback.toString(), cookieOptions(10 * 60 * 1000));
  const authorizationUrl = new URL("https://github.com/login/oauth/authorize");
  authorizationUrl.searchParams.set("client_id", clientId);
  authorizationUrl.searchParams.set("redirect_uri", callback.toString());
  authorizationUrl.searchParams.set("scope", "repo read:user");
  authorizationUrl.searchParams.set("state", state);

  res.redirect(authorizationUrl.toString());
});

router.get("/github/auth/callback", async (req, res) => {
  const clientId = process.env.GITHUB_CLIENT_ID;
  const clientSecret = process.env.GITHUB_CLIENT_SECRET;
  const code = typeof req.query.code === "string" ? req.query.code : "";
  const state = typeof req.query.state === "string" ? req.query.state : "";
  const expectedState = req.signedCookies?.[githubStateCookie] as string | undefined;
  const callbackUrl =
    (req.signedCookies?.[githubRedirectCookie] as string | undefined) ||
    process.env.GITHUB_REDIRECT_URI ||
    `${getOrigin(req)}/api/github/auth/callback`;

  res.clearCookie(githubStateCookie, { path: "/" });
  res.clearCookie(githubRedirectCookie, { path: "/" });
  if (!clientId || !clientSecret || !code || !state || !expectedState || state !== expectedState) {
    res.redirect("/?github=error");
    return;
  }

  const tokenResponse = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      code,
      redirect_uri: callbackUrl,
    }),
  });
  const tokenData = (await tokenResponse.json().catch(() => ({}))) as { access_token?: string };
  if (!tokenResponse.ok || !tokenData.access_token) {
    res.redirect("/?github=error");
    return;
  }

  res.cookie(githubTokenCookie, tokenData.access_token, cookieOptions(30 * 24 * 60 * 60 * 1000));
  res.redirect("/?github=connected");
});

router.post("/github/auth/logout", (req, res) => {
  res.clearCookie(githubTokenCookie, { path: "/" });
  res.json(LogoutGithubResponse.parse({ message: "GitHub disconnected." }));
});

router.get("/github/repositories", async (req, res) => {
  const token = getToken(req);
  if (!token) {
    res.status(401).json({ error: "Connect GitHub before loading repositories." });
    return;
  }

  const result = await listGithubRepositories(token);
  if (!result.response.ok) {
    res.status(githubErrorStatus(result.response.status)).json({
      error: errorMessage(result.data, "Unable to load GitHub repositories."),
    });
    return;
  }

  const repositories = result.data.map((repository) => ({
    id: repository.id,
    name: repository.name,
    fullName: repository.full_name,
    private: repository.private,
    defaultBranch: repository.default_branch,
    htmlUrl: repository.html_url,
    description: repository.description,
  }));
  res.json(ListGithubRepositoriesResponse.parse(repositories));
});

router.post("/github/repositories", async (req, res) => {
  const token = getToken(req);
  if (!token) {
    res.status(401).json({ error: "Connect GitHub before creating a repository." });
    return;
  }

  const parsed = CreateGithubRepositoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a valid repository name." });
    return;
  }

  const result = await createGithubRepository(
    token,
    parsed.data.name.trim(),
    parsed.data.description?.trim() || "",
    parsed.data.private,
  );
  if (!result.response.ok) {
    res.status(githubErrorStatus(result.response.status)).json({
      error: errorMessage(result.data, "GitHub could not create the repository."),
    });
    return;
  }

  res.status(201).json(
    CreateGithubRepositoryResponse.parse({
      id: result.data.id,
      name: result.data.name,
      fullName: result.data.full_name,
      private: result.data.private,
      defaultBranch: result.data.default_branch,
      htmlUrl: result.data.html_url,
      description: result.data.description,
    }),
  );
});

router.post("/github/repositories/empty", async (req, res) => {
  const token = getToken(req);
  if (!token) {
    res.status(401).json({ error: "Connect GitHub before emptying a repository." });
    return;
  }

  const parsed = EmptyGithubRepositoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a repository, a branch, and enter EMPTY to confirm." });
    return;
  }
  if (parsed.data.confirmation.trim().toUpperCase() !== "EMPTY") {
    res.status(400).json({ error: 'Type "EMPTY" to confirm this destructive action.' });
    return;
  }

  const branch = parsed.data.branch.trim();
  const repository = parseRepositoryUrl(parsed.data.repositoryUrl);
  if (!repository || !branch) {
    res.status(400).json({ error: "Enter a valid GitHub repository URL and branch." });
    return;
  }

  const repositoryResult = await getGithubRepository(token, repository.owner, repository.repo);
  if (!repositoryResult.response.ok) {
    res.status(githubErrorStatus(repositoryResult.response.status)).json({
      error: errorMessage(repositoryResult.data, "The selected repository could not be found."),
    });
    return;
  }

  const refResult = await getGithubRef(token, repository.owner, repository.repo, branch);
  if (!refResult.response.ok) {
    res.status(githubErrorStatus(refResult.response.status)).json({
      error: errorMessage(refResult.data, `The "${branch}" branch could not be found.`),
    });
    return;
  }

  const baseCommitSha = refResult.data.object.sha;
  const baseTreeSha = await getGithubCommitTree(token, repository.owner, repository.repo, baseCommitSha);
  if (!baseTreeSha) {
    res.status(502).json({ error: "GitHub could not read the current repository tree." });
    return;
  }

  const treeResult = await getGithubTree(token, repository.owner, repository.repo, baseTreeSha);
  if (!treeResult.response.ok) {
    res.status(502).json({
      error: errorMessage(treeResult.data, "GitHub could not read the files in this branch."),
    });
    return;
  }
  if (treeResult.data.truncated) {
    res.status(502).json({
      error: "This branch contains too many files to clear safely in one operation.",
    });
    return;
  }

  const rootEntries = treeResult.data.tree
    .filter((entry) => !entry.path.includes("/"))
    .map((entry) => ({
      path: entry.path,
      mode: entry.mode,
      type: entry.type,
      sha: null,
    }));

  if (rootEntries.length === 0) {
    res.json(
      EmptyGithubRepositoryResponse.parse({
        repository: `${repository.owner}/${repository.repo}`,
        branch,
        commitSha: null,
        deletedCount: 0,
        message: "This branch is already empty.",
      }),
    );
    return;
  }

  const emptyTreeResult = await createGithubTree(
    token,
    repository.owner,
    repository.repo,
    baseTreeSha,
    rootEntries,
  );
  if (!emptyTreeResult.response.ok) {
    res.status(502).json({
      error: errorMessage(emptyTreeResult.data, "GitHub could not prepare the empty tree."),
    });
    return;
  }

  const commitResult = await createGithubCommit(
    token,
    repository.owner,
    repository.repo,
    `Empty ${branch} via Easy Upload`,
    emptyTreeResult.data.sha,
    baseCommitSha,
  );
  if (!commitResult.response.ok) {
    res.status(502).json({
      error: errorMessage(commitResult.data, "GitHub could not create the emptying commit."),
    });
    return;
  }

  const refUpdate = await updateGithubRef(
    token,
    repository.owner,
    repository.repo,
    branch,
    commitResult.data.sha,
  );
  if (!refUpdate.response.ok) {
    if (refUpdate.response.status === 403 || refUpdate.response.status === 422) {
      res.status(403).json({
        error: `GitHub rejected the update because the "${branch}" branch may be protected.`,
      });
      return;
    }
    if (refUpdate.response.status === 409) {
      res.status(409).json({
        error: `The "${branch}" branch changed while it was being emptied. Nothing was overwritten; review it and try again.`,
      });
      return;
    }
    res.status(502).json({
      error: errorMessage(refUpdate.data, "GitHub could not update the branch."),
    });
    return;
  }

  res.json(
    EmptyGithubRepositoryResponse.parse({
      repository: `${repository.owner}/${repository.repo}`,
      branch,
      commitSha: commitResult.data.sha,
      deletedCount: rootEntries.length,
      message: `The "${branch}" branch is now empty.`,
    }),
  );
});

router.post("/github/upload", async (req, res) => {
  const token = getToken(req);
  if (!token) {
    res.status(401).json({ error: "Connect GitHub before uploading." });
    return;
  }

  const parsed = UploadToGithubBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please review the upload details and selected files." });
    return;
  }

  const { repositoryUrl, targetPath, branch, commitMessage, files } = parsed.data;
  const repository = parseRepositoryUrl(repositoryUrl);
  if (!repository) {
    res.status(400).json({ error: "Enter a valid GitHub repository URL." });
    return;
  }

  const normalizedTarget = targetPath.trim().replace(/^\/+|\/+$/g, "");
  const uploadItems = files.map((file) => {
    const filePath = file.path.replaceAll("\\", "/").replace(/^\/+/, "");
    const combinedPath = [normalizedTarget, filePath].filter(Boolean).join("/");
    return { ...file, combinedPath };
  });
  if (
    uploadItems.some(
      (file) =>
        !file.combinedPath ||
        file.combinedPath.split("/").some((part) => part === ".." || part === ".") ||
        file.combinedPath.includes("\0"),
    )
  ) {
    res.status(400).json({ error: "One or more file paths are invalid." });
    return;
  }

  const repositoryResult = await getGithubRepository(token, repository.owner, repository.repo);
  if (!repositoryResult.response.ok) {
    res.status(githubErrorStatus(repositoryResult.response.status)).json({
      error: errorMessage(repositoryResult.data, "The selected repository could not be found."),
    });
    return;
  }

  const refResult = await getGithubRef(token, repository.owner, repository.repo, branch);
  if (!refResult.response.ok) {
    if (refResult.response.status === 404 && repositoryResult.data.size === 0) {
      let lastCommitSha: string | null = null;
      const emptyRepositoryItems: Array<{
        path: string;
        status: "created" | "updated" | "failed";
        message: string;
      }> = [];

      for (const [index, file] of uploadItems.entries()) {
        const contentResult = await createGithubContent(
          token,
          repository.owner,
          repository.repo,
          file.combinedPath,
          file.contentBase64,
          commitMessage,
          index === 0 ? undefined : branch,
        );
        if (!contentResult.response.ok) {
          emptyRepositoryItems.push({
            path: file.combinedPath,
            status: "failed",
            message: errorMessage(contentResult.data, "GitHub rejected this file."),
          });
          continue;
        }
        lastCommitSha = contentResult.data.commit.sha;
        emptyRepositoryItems.push({
          path: file.combinedPath,
          status: "created",
          message: "Uploaded to the new repository",
        });

        if (index === 0 && repositoryResult.data.default_branch !== branch) {
          const branchResult = await createGithubRef(
            token,
            repository.owner,
            repository.repo,
            branch,
            contentResult.data.commit.sha,
          );
          if (!branchResult.response.ok) {
            res.status(githubErrorStatus(branchResult.response.status)).json({
              error: errorMessage(branchResult.data, `GitHub could not create the "${branch}" branch.`),
            });
            return;
          }
        }
      }

      const emptyResponse = {
        repository: `${repository.owner}/${repository.repo}`,
        branch,
        commitSha: lastCommitSha,
        total: emptyRepositoryItems.length,
        succeeded: emptyRepositoryItems.filter((item) => item.status !== "failed").length,
        failed: emptyRepositoryItems.filter((item) => item.status === "failed").length,
        items: emptyRepositoryItems,
      };
      if (emptyResponse.succeeded === 0) {
        res.status(400).json({ error: "GitHub could not create the first file in this empty repository." });
        return;
      }
      res.json(UploadToGithubResponse.parse(emptyResponse));
      return;
    }
    res.status(githubErrorStatus(refResult.response.status)).json({
      error: errorMessage(refResult.data, "The selected branch could not be found."),
    });
    return;
  }

  const baseCommitSha = refResult.data.object.sha;
  const treeEntries: Array<{ path: string; mode: "100644"; type: "blob"; sha: string }> = [];
  const items: Array<{ path: string; status: "created" | "updated" | "failed"; message: string }> = [];

  for (const file of uploadItems) {
    const blobResult = await createGithubBlob(
      token,
      repository.owner,
      repository.repo,
      file.contentBase64,
    );
    if (!blobResult.response.ok) {
      items.push({
        path: file.combinedPath,
        status: "failed",
        message: errorMessage(blobResult.data, "GitHub rejected this file."),
      });
      continue;
    }
    treeEntries.push({
      path: file.combinedPath,
      mode: "100644",
      type: "blob",
      sha: blobResult.data.sha,
    });
    items.push({
      path: file.combinedPath,
      status: "created",
      message: "Ready in commit",
    });
  }

  if (treeEntries.length === 0) {
    res.status(400).json({ error: "No files could be prepared for upload." });
    return;
  }

  const baseTreeSha = await getGithubCommitTree(token, repository.owner, repository.repo, baseCommitSha);
  if (!baseTreeSha) {
    res.status(502).json({ error: "GitHub could not read the current repository tree." });
    return;
  }

  const treeResult = await createGithubTree(
    token,
    repository.owner,
    repository.repo,
    baseTreeSha,
    treeEntries,
  );
  if (!treeResult.response.ok) {
    res.status(502).json({ error: errorMessage(treeResult.data, "GitHub could not create the file tree.") });
    return;
  }

  const commitResult = await createGithubCommit(
    token,
    repository.owner,
    repository.repo,
    commitMessage,
    treeResult.data.sha,
    baseCommitSha,
  );
  if (!commitResult.response.ok) {
    res.status(502).json({ error: errorMessage(commitResult.data, "GitHub could not create the commit.") });
    return;
  }

  let finalCommitSha = commitResult.data.sha;
  let refUpdate = await updateGithubRef(
    token,
    repository.owner,
    repository.repo,
    branch,
    finalCommitSha,
  );

  if (!refUpdate.response.ok && [409, 422].includes(refUpdate.response.status)) {
    const latestRef = await getGithubRef(token, repository.owner, repository.repo, branch);
    // Rebuild only when the branch really moved after we read it. A 422 can
    // also mean that the branch is protected, in which case creating another
    // orphan commit would not help.
    if (latestRef.response.ok && latestRef.data.object.sha !== baseCommitSha) {
      const latestTreeSha = await getGithubCommitTree(
        token,
        repository.owner,
        repository.repo,
        latestRef.data.object.sha,
      );
      if (latestTreeSha) {
        const retryTree = await createGithubTree(
          token,
          repository.owner,
          repository.repo,
          latestTreeSha,
          treeEntries,
        );
        if (retryTree.response.ok) {
          const retryCommit = await createGithubCommit(
            token,
            repository.owner,
            repository.repo,
            commitMessage,
            retryTree.data.sha,
            latestRef.data.object.sha,
          );
          if (retryCommit.response.ok) {
            finalCommitSha = retryCommit.data.sha;
            refUpdate = await updateGithubRef(
              token,
              repository.owner,
              repository.repo,
              branch,
              finalCommitSha,
            );
          }
        }
      }
    }
  }

  if (!refUpdate.response.ok) {
    if (refUpdate.response.status === 403 || refUpdate.response.status === 422) {
      res.status(403).json({
        error: `GitHub rejected the update because the "${branch}" branch may be protected or does not allow direct pushes. Choose an unprotected branch or allow this GitHub account to push to it.`,
      });
      return;
    }
    if (refUpdate.response.status === 409) {
      res.status(409).json({
        error: `The "${branch}" branch changed while the files were uploading. Please try the upload again.`,
      });
      return;
    }
    res.status(502).json({ error: errorMessage(refUpdate.data, "GitHub could not update the branch.") });
    return;
  }

  const response = {
    repository: `${repository.owner}/${repository.repo}`,
    branch,
    commitSha: finalCommitSha,
    total: items.length,
    succeeded: items.filter((item) => item.status !== "failed").length,
    failed: items.filter((item) => item.status === "failed").length,
    items,
  };
  res.json(UploadToGithubResponse.parse(response));
});

async function getGithubCommitTree(
  token: string,
  owner: string,
  repo: string,
  sha: string,
) {
  const response = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/commits/${sha}`, {
    headers: {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${token}`,
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": "Easy-Upload",
    },
  });
  if (!response.ok) return null;
  const data = (await response.json()) as { tree?: { sha?: string } };
  return data.tree?.sha || null;
}

export default router;