const GITHUB_API = "https://api.github.com";

type GithubResponse<T> = {
  data: T;
  response: Response;
};

export type GithubRepositoryApi = {
  id: number;
  name: string;
  full_name: string;
  private: boolean;
  default_branch: string;
  html_url: string;
  description: string | null;
  size: number;
};

export type GithubUserApi = {
  login: string;
  avatar_url: string;
};

export type GithubRefApi = {
  object: { sha: string };
};

export type GithubCommitApi = {
  sha: string;
  tree: { sha: string };
};

export type GithubTreeEntryApi = {
  path: string;
  mode: string;
  type: "blob" | "tree" | "commit";
  sha: string;
};

function headers(token: string, accept = "application/vnd.github+json") {
  return {
    Accept: accept,
    Authorization: `Bearer ${token}`,
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
    "User-Agent": "Easy-Upload",
  };
}

function encodeRefPath(ref: string) {
  return ref
    .split("/")
    .map((segment) => encodeURIComponent(segment))
    .join("/");
}

async function githubRequest<T>(
  token: string,
  path: string,
  init: RequestInit = {},
): Promise<GithubResponse<T>> {
  const response = await fetch(`${GITHUB_API}${path}`, {
    ...init,
    headers: {
      ...headers(token),
      ...(init.headers ?? {}),
    },
  });
  const data = (await response.json().catch(() => ({}))) as T;
  return { data, response };
}

export function parseRepositoryUrl(repositoryUrl: string) {
  let parsed: URL;
  try {
    parsed = new URL(repositoryUrl);
  } catch {
    return null;
  }

  if (parsed.hostname.toLowerCase() !== "github.com") return null;
  const parts = parsed.pathname
    .replace(/^\/+|\/+$/g, "")
    .split("/")
    .filter(Boolean);
  if (parts.length !== 2) return null;

  const owner = parts[0];
  const repo = parts[1].replace(/\.git$/i, "");
  if (!owner || !repo || !/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repo)) {
    return null;
  }

  return { owner, repo };
}

export async function getGithubUser(token: string) {
  return githubRequest<GithubUserApi>(token, "/user");
}

export async function listGithubRepositories(token: string) {
  return githubRequest<GithubRepositoryApi[]>(
    token,
    "/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member",
  );
}

export async function getGithubRepository(
  token: string,
  owner: string,
  repo: string,
) {
  return githubRequest<GithubRepositoryApi>(token, `/repos/${owner}/${repo}`);
}

export async function createGithubRepository(
  token: string,
  name: string,
  description: string,
  isPrivate: boolean,
) {
  return githubRequest<GithubRepositoryApi>(token, "/user/repos", {
    method: "POST",
    body: JSON.stringify({
      name,
      description: description || undefined,
      private: isPrivate,
      auto_init: true,
    }),
  });
}

export async function getGithubRef(
  token: string,
  owner: string,
  repo: string,
  branch: string,
) {
  return githubRequest<GithubRefApi>(
    token,
    `/repos/${owner}/${repo}/git/ref/heads/${encodeRefPath(branch)}`,
  );
}

export async function createGithubBlob(
  token: string,
  owner: string,
  repo: string,
  contentBase64: string,
) {
  return githubRequest<{ sha: string }>(
    token,
    `/repos/${owner}/${repo}/git/blobs`,
    {
      method: "POST",
      body: JSON.stringify({ content: contentBase64, encoding: "base64" }),
    },
  );
}

export async function createGithubTree(
  token: string,
  owner: string,
  repo: string,
  baseTree: string,
  tree: Array<{ path: string; mode: string; type: "blob" | "tree" | "commit"; sha: string | null }>,
) {
  return githubRequest<{ sha: string }>(
    token,
    `/repos/${owner}/${repo}/git/trees`,
    {
      method: "POST",
      body: JSON.stringify({ base_tree: baseTree, tree }),
    },
  );
}

export async function getGithubTree(
  token: string,
  owner: string,
  repo: string,
  treeSha: string,
) {
  return githubRequest<{ tree: GithubTreeEntryApi[]; truncated: boolean }>(
    token,
    `/repos/${owner}/${repo}/git/trees/${encodeURIComponent(treeSha)}?recursive=1`,
  );
}

export async function createGithubCommit(
  token: string,
  owner: string,
  repo: string,
  message: string,
  tree: string,
  parent: string,
) {
  return githubRequest<GithubCommitApi>(
    token,
    `/repos/${owner}/${repo}/git/commits`,
    {
      method: "POST",
      body: JSON.stringify({ message, tree, parents: [parent] }),
    },
  );
}

export async function updateGithubRef(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  sha: string,
) {
  return githubRequest<{ object: { sha: string } }>(
    token,
    `/repos/${owner}/${repo}/git/refs/heads/${encodeRefPath(branch)}`,
    {
      method: "PATCH",
      body: JSON.stringify({ sha, force: false }),
    },
  );
}

export async function createGithubRef(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  sha: string,
) {
  return githubRequest<{ object: { sha: string } }>(
    token,
    `/repos/${owner}/${repo}/git/refs`,
    {
      method: "POST",
      body: JSON.stringify({ ref: `refs/heads/${branch}`, sha }),
    },
  );
}

export async function createGithubContent(
  token: string,
  owner: string,
  repo: string,
  path: string,
  contentBase64: string,
  message: string,
  branch?: string,
) {
  const encodedPath = path
    .split("/")
    .map((segment) => encodeURIComponent(segment))
    .join("/");
  const body: { message: string; content: string; branch?: string } = {
    message,
    content: contentBase64,
  };
  if (branch) body.branch = branch;

  return githubRequest<{ commit: { sha: string } }>(
    token,
    `/repos/${owner}/${repo}/contents/${encodedPath}`,
    {
      method: "PUT",
      body: JSON.stringify(body),
    },
  );
}